import { Message } from "./message";

export class Chat {
    chatId:Number;
    ownerEmail:string;
    buyerEmail:string;
    messageList:Message[];

    constructor(){
        
    }
}
