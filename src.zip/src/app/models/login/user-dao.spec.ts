import { UserDao } from './user-dao';

describe('UserDao', () => {
  it('should create an instance', () => {
    expect(new UserDao()).toBeTruthy();
  });
});
