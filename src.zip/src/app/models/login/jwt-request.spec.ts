import { JwtRequest } from './jwt-request';

describe('JwtRequest', () => {
  it('should create an instance', () => {
    expect(new JwtRequest()).toBeTruthy();
  });
});
