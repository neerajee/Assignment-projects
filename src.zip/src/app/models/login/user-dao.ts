export class UserDao {
    username:string;
    password:string;
    constructor(){}
}
