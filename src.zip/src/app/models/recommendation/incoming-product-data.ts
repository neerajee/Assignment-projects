export class IncomingProductData {
    productId:number;
    productOwnerEmail:String;
    productName:String;
    state:String;
    city:String;
    productCategory:String;
    productImage:any;
    constructor(){

    }
}
