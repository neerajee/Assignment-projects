export class Category {
    productCategory:"String"
    constructor(){

    }
}
