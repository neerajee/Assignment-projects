export class Location {
    city:String;
    state:String;
    constructor(){}
}
