export class User {
    id:number;
    email:String;
    constructor(){

    }
}


