import { IncomingProductData } from './incoming-product-data';

describe('IncomingProductData', () => {
  it('should create an instance', () => {
    expect(new IncomingProductData()).toBeTruthy();
  });
});
