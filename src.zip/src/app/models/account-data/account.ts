export class Account {
  
    accountNumber: number;
    email: string;
    expiryMonth: string;
    cvv : number;
    accountHolderName : string;
    amount:number;

    constructor(){
        
    }

}
