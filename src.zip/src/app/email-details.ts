export class EmailDetails {
    recipient:String;
    msgBody:String;
    subject:String;

    constructor() {
        
    }
}
