export class Product {
    pid
    pemail
    pname
    pcategory
    pstate
    pstatus
    pdate
    pexchange
    pexchangetype
    pcoin
    desc
    image
    pdatepost
}
