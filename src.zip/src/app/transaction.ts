export class Transaction {
  buyerEmail: String;
  sellerEmail: String;
  productSend: String;
  productObtained: String;
  method_of_Transaction: String;
  price_of_Product_in_coins: any;
  historyDetails: String;

constructor() {

}
}