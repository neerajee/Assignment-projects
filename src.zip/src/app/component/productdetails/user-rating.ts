export class UserRating {
    email:string;
    avgRating:any;
    ratings:[]

    constructor(){
        
    }
}
