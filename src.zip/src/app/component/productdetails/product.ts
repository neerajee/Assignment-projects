

export class Product {
   public pid:Number;
   public pemail:string;
   public pname:string;
    pcategory:string;
    // plocation:string;
    pstate:string;
    pcity:string;
    pstatus:string;
    pdate:string;
    pexchange:[]
    pexchangetype:string;
    pcoin:number;
    desc:string;
    img:any;
    pdatepost:string

    

    // constructor(pid:number,pemail:string, pname:string,pcategory:string,plocation:string,pstatus:string, pdate:Date,pexchange:string,pcoin:number,desc:string,img:any){
    // this.pid=pid;
    // this.pemail=pemail;
    // this.pname=pname
    // this.pcategory=pcategory;
    // this.plocation=plocation;
    // this.pstatus=pstatus;
    // this.pdate=pdate;
    // this.pexchange=pexchange;
    // this.pcoin=pcoin;
    // this.desc=desc;
    // this.img=img;
    // };
    constructor(){

    }
    
}
