import { UserRating } from './user-rating';

describe('UserRating', () => {
  it('should create an instance', () => {
    expect(new UserRating()).toBeTruthy();
  });
});
