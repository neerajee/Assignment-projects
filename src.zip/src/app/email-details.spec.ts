import { EmailDetails } from './email-details';

describe('EmailDetails', () => {
  it('should create an instance', () => {
    expect(new EmailDetails()).toBeTruthy();
  });
});
