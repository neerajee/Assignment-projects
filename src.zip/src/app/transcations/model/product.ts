export class Product {
    pid;
	pemail;
	pname;
	pcategory;
	pstate;
	pcity;
	pstatus 
	pdate
    pdatepost;
	pexchange;
	pcoin;
	pexchangetype;
	desc;
	image;
}
