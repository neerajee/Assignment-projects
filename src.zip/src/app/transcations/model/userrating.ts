export class Userrating {
    userId:string
	   rating
	    reviews:string
}
