export class Abc {
    a
  b
}
