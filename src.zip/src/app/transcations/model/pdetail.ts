export class Pdetail {
    pcoin1
    pname1
    pcategory1
    pcoin2
    pname2
    pcategory2
    ename
    eemail
    image1
    image2

}
