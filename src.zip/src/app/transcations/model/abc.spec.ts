import { Abc } from './abc';

describe('Abc', () => {
  it('should create an instance', () => {
    expect(new Abc()).toBeTruthy();
  });
});
