export class UserRegistration {

  firstname: String;
  lastname: String;
  age: String;
  gender: String;
  email: String;
  mobile: String;
  password: String;
  cpassword: String;
  accept: String;
  street:String;
  city:String;
  state:String;
  pincode:string;
  image: any;
  acoin:any;
  price:any;
  barterCoins:any;

  constructor() {
    this.firstname = "";
    this.lastname = "";
    this.age = "";
    this.gender = "";
    this.email = "";
    this.mobile = "";
    this.password = "";
    this.cpassword = "";
    this.street = "";
    this.city = "";
    this.state = "";
    this.pincode = "";
    
  }
}
