export const environment = {
  production: true,
  local: 'production',
  apiBaseUrl: 'http://43.205.222.181:8080'
};
